training_data = [
    [1, 1, 'Yes'],
    [1, 2, 'Yes'],
    [1, 3, 'No'],
    [1, 4, 'No'],
    [2, 1, 'Yes'],
    [2, 2, 'Yes'],
    [2, 4, 'Yes'],
    [2, 5, 'No'],
    [2, 10, 'No'],
    [2, 8, 'No'],
]


header = ["mirror", "readers", "issue"]

from collections import defaultdict

class Question:

    def __init__(self, column, value):
        self.column = column
        self.value = value

    def match(self, example):
        val = example[self.column]
        return val > self.value

class Leaf:
    def __init__(self, rows):
        self.predictions = label_counts(rows)

class Decision_Node:
    def __init__(self,
                 question,
                 true_branch,
                 false_branch):
        self.question = question
        self.true_branch = true_branch
        self.false_branch = false_branch


def label_counts(rows):
    counts = defaultdict(int) # a dictionary of label -> count.
    for row in rows:
        label = row[-1]
        counts[label] += 1
    return counts

def partition(rows, question):

    true_rows, false_rows = [], []
    for row in rows:
        if question.match(row):
            true_rows.append(row)
        else:
            false_rows.append(row)
    return true_rows, false_rows

def gini(rows):
    counts = label_counts(rows)
    impurity = 1
    for lbl in counts:
        prob_of_lbl = counts[lbl] / float(len(rows))
        impurity -= prob_of_lbl**2
    return impurity

def info_gain(left, right, current_uncertainty):
    p = float(len(left)) / (len(left) + len(right))
    return current_uncertainty - p * gini(left) - (1 - p) * gini(right)

def find_best_split(rows):

    best_gain = 0  # keep track of the best information gain
    best_question = None  # keep train of the feature / value that produced it
    current_uncertainty = gini(rows)
    n_features = len(rows[0]) - 1  # number of columns

    for col in range(n_features):  # for each feature

        values = set([row[col] for row in rows])  # unique values in the column

        for val in values:  

            question = Question(col, val)
            true_rows, false_rows = partition(rows, question)

            if len(true_rows) == 0 or len(false_rows) == 0:
                continue
            gain = info_gain(true_rows, false_rows, current_uncertainty)

            if gain > best_gain:
                best_gain, best_question = gain, question

    return best_gain, best_question



def build_tree(rows):
    gain, question = find_best_split(rows)

    if gain == 0:
        return Leaf(rows)

    true_rows, false_rows = partition(rows, question)
    true_branch = build_tree(true_rows)
    false_branch = build_tree(false_rows)
    return Decision_Node(question, true_branch, false_branch)

my_tree = build_tree(training_data)

def classify(row, node):

    if isinstance(node, Leaf):
        return node.predictions

    if node.question.match(row):
        return classify(row, node.true_branch)
    else:
        return classify(row, node.false_branch)


testing_data = [
    [2, 1, 'Yes'],
    [1, 6, 'No'],
    [2, 9, 'No'],
]

for row in testing_data:
    print ("Actual: %s. Predicted: %s" %
           (row[-1], str(classify(row, my_tree).keys())))





