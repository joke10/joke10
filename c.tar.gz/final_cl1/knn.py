from math import * 
 
def euclidean_distance(point1, point2): 
    return(sqrt((point1[0]-point2[0]) * (point1[0]-point2[0]) + (point1[1]-point2[1]) * (point1[1]-point2[1]))) 
 
dataset = [[(1,1), 1, 0], [(2,2), 1, 0], [(2,3), 1, 0], [(3,2), 0, 0], [(3, 4), 1, 0], [(1,4), 0, 0], 
           [(2,5), 1, 0], [(2,7), 1, 0], [(1,9), 0, 0], [(4,6), 1, 0], [(4,9), 0, 0], [(5, 8), 0, 0], 
           [(5,10), 1, 0], [(5,4), 0, 0], [(7,2), 0, 0], [(7,9), 1, 0], [(6,5), 0, 0], [(7,4), 0, 0], 
           [(7,6), 0, 0], [(8,4), 0, 0], [(8,5), 0, 0], [(8,6), 0, 0]] 
 
points = [] 
label = []
 
for i in range(len(dataset)): 
    points.append(dataset[i][0]) #points 
    label.append(dataset[i][1]) #label 
 
input_x = int(input("Enter X co-ordinate: "))
input_y = int(input("Enter Y co-ordinate: ")) 
input_data = tuple((input_x,input_y))

 
for i in range(len(points)): 
    dataset[i][2] = euclidean_distance(points[i], input_data)
    
     
dataset = sorted(dataset, key=lambda x: float(x[2])) 
 
print(dataset) 
 
no_of_neighbors = int(input("Enter k : ")) 
output_label = []
 
for k in range(no_of_neighbors): 
    output_label.append(dataset[k][1]) 
 
print(output_label) 
label_0 = 0 
label_1 = 0 
 
for value in output_label: 
    if value == 0: 
        label_0+= 1 
    elif value == 1: 
        label_1+=1 
 
if label_0 > label_1: 
    print("The class assigned to the point is: 0") 
elif label_1 > label_0: 
    print("The class assigned to the point is: 1") 
elif label_0 == label_1: 
    print("Equal probability of output label. Please select odd value of k next time.")
