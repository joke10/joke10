#include <stdio.h>
#include <ctype.h>
#include <string.h>

int i=0,error=0;
char input[10];
void E();
void T();
void Eprime();
void Tprime();
void F();

int main()
{
	printf("\nEnter the input string to be parsed: ");
	gets(input);
	E();
	if(i==strlen(input) && error == 0)
		printf("\nInput Accepted");
	else
		printf("\nInput Rejected");
}

void E()
{
	T();
	Eprime();
}

void T()
{
	F();
	Tprime();
}

void F()
{
	if(isalnum(input[i]))
		i++;

	else if(input[i]=='(')
	{
		i++;
		E();
		if(input[i]==')')
			i++;
		else
			error = 1;
	}
	else
		error = 1;
}

void Eprime()
{
	if(input[i]=='+')
	{
		i++;
		T();
		Eprime();
	}
	else
		return;
}

void Tprime()
{
	if(input[i]=='*')
	{
		i++;
		F();
		Tprime();
	}
	else
		return;
}


