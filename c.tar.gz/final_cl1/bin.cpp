#include<iostream>
#include<stdlib.h>
#include<time.h>
#define MAX 1000
using namespace std;

int recursive_search(int arr[],int left,int right,int key)
{
	if(right>=left)
	{
		int mid = left + (right-1)/2;
		if(arr[mid]==key) return mid;
		else if(arr[mid]>key) recursive_search(arr,left,mid-1,key);
		else recursive_search(arr,mid+1,right,key);
	}
	return -1;
}

int iterative_search(int arr[],int left,int right,int key)
{
	while(right>=left)
	{
		int mid = left + (right-1)/2;
		if(arr[mid]==key) return mid;
		else if(arr[mid]>key) right = mid-1;
		else left = mid+1;
	}
	return -1;
}

int optimal_search(int arr[],int left,int right,int key)
{
	int mid = left + (right-1)/2;
	while(arr[mid]!=key && right>=left)
	{
		if(arr[mid]>key) right = mid-1;
		else left = mid+1;
		int mid = left + (right-1)/2;
	}
	if(arr[mid]==key)
		return mid;
	else
		return -1;
}

void run(int arr[], int n ,int key)
{
	clock_t start , stop;
	start = clock();
	int index = recursive_search(arr,0,n-1,key);
	stop = clock();
	cout<<"Time for recursive : "<<(float)(stop-start)/CLOCKS_PER_SEC<<endl;
	cout<<"Element found at index: "<<index<<endl;
	start = clock();
	index = iterative_search(arr,0,n-1,key);
	stop = clock();
	cout<<"Time for iterative : "<<(float)(stop-start)/CLOCKS_PER_SEC<<endl;
	cout<<"Element found at index: "<<index;
	start = clock();
	index = optimal_search(arr,0,n-1,key);
	stop = clock();
	cout<<"Time for optimal_iterative : "<<(float)(stop-start)/CLOCKS_PER_SEC<<endl;
	cout<<"Element found at index: "<<index;
}
int main(int argc,char *argv[])
{
	int arr[MAX];
	//int n =atoi(argv[1]);
	//cout<<n;
	int n =1000;
	for(int i=0;i<n;i++)
	{
		arr[i]=rand()%100;
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n-1-i;j++)
		{
			if(arr[j]>arr[j+1])
			{
				int temp = arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
	

	int key;
	key = arr[(n/2)-1]; //best case
	cout<<"\n BEST CASE: ";
	run(arr, n , key);
	cout<<"\n Worst CASE: ";
	key = -1; //worst case
	run(arr, n ,key);
	cout<<"\n average CASE: ";
	key = rand()%100; //average
	run(arr, n ,key);


	return 0;
}	
