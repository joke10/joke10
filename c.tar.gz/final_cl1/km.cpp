#include <iostream>
#include <stdlib.h>
#include <math.h>
#include <algorithm>
#include <vector>

using namespace std;
class Point
{
    private:
        int point_id , cluster_id, total_features;
        vector <double> features;
        string name;
    public:
        Point(int point_id,vector <double> & features, string name="")
        {
            this->point_id = point_id;
            total_features = features.size();
            for(int i=0;i<total_features;i++)
            {
                this->features.push_back(features[i]);
            }
            this->name = name;
            cluster_id = -1;
        }

        int getID()
        {
            return point_id;
        }
        
        int getClusterID()
        {
            return cluster_id;
        }
        
        int setClusterID(int cluster_id)
        {
            this->cluster_id = cluster_id;
        }
        
        double getValue(int index)
        {
            return features[index];
        }
    
        int getTotalValues()
        {
            return total_features;
        }
        
        string getName()
        {
            if(name == "")
                return "-";
            else            
                return name;
        }
};

class Cluster
{
    private:
        int cluster_id;
        vector <Point> cluster_points;
        vector <double> centre_values;

    public:
        Cluster(int cluster_id, Point point)
        {
            this->cluster_id = cluster_id;
            int total_features = point.getTotalValues();
            for(int i=0;i<total_features;i++)
            {
                centre_values.push_back(point.getValue(i));
            }
            cluster_points.push_back(point);
        }

        int getClusterID()
        {
            return cluster_id;
        }
    
        void setClusterID(int cluster_id)
        {
            this->cluster_id = cluster_id;
        }
    
        Point getPoint(int index)
        {
            return cluster_points[index];
        }

        int getTotalPointsInCluster()
        {
            return cluster_points.size();
        }

        void addPoint(Point point)
        {
            cluster_points.push_back(point);
        }

        bool removePoint(int point_id)
        {
            for(int i=0;i<cluster_points.size();i++)
            {
                if(cluster_points[i].getID() == point_id)
                {
                    cluster_points.erase(cluster_points.begin()+i);
                }
                return true; 
            }
            return false;
        }

        double getCentreValue(int index)
        {
            return centre_values[index];
        }
        
        void setCentreValue(int index, double value)
        {
            centre_values[index]=value;
        }
};

class Kmeans
{
    private:
        int total_points,total_features,K,max_iterations;
        vector <Cluster> clusters;

        int getIDNearestCentre(Point point)
        {
            int id_cluster_centre =0;
            double sum = 0.0 , min_distance;
            for(int i=0;i<total_features;i++)
            {
                sum +=pow(clusters[0].getCentreValue(i)-point.getValue(i),2.0);
            }
            min_distance = sqrt(sum);

            for(int i=1;i<K;i++)
            {
                double distance;
                sum = 0.0;
                for(int j=0;j<total_features;j++)
                {
                    sum +=pow(clusters[i].getCentreValue(j) - point.getValue(j), 2.0);
                }
                distance = sqrt(sum);
                if(distance<min_distance)
                {
                    min_distance = distance;
                    id_cluster_centre = i;
                }
            }
            return id_cluster_centre;
        }

    public:
        Kmeans(int total_points, int total_features, int K, int max_iterations)
        {
            this->total_points = total_points;
            this->total_features = total_features;
            this->K = K;
            this->max_iterations = max_iterations;
        }

        void run(vector <Point>& points)
        {
            if(K>total_points)
                return;

            vector <int> prohibited_points;
            for(int i=0;i<K;i++)
            {
                while(true)
                {
                    int index_point = rand()%total_points;
                    
                    if(find(prohibited_points.begin(),prohibited_points.end(),index_point)==prohibited_points.end())
                    {
                        cout<<"\n\nIndex point is : ",index_point;
                        prohibited_points.push_back(index_point);
                        points[index_point].setClusterID(i);
                        Cluster cluster(i,points[index_point]);
                        clusters.push_back(cluster);
                        break;
                    }
                }
            }
            
            int iteration = 1;
            while(true)
            {
                bool done = true;
                for(int i=0;i<total_points;i++)
                {
                    int id_old_cluster = points[i].getClusterID();
                    int id_nearest_centre = getIDNearestCentre(points[i]);
                    
                    if(id_old_cluster != id_nearest_centre)
                    { 
                        if(id_old_cluster != -1)
                        {
                            clusters[id_old_cluster].removePoint(points[i].getID());
                        }
                        clusters[id_nearest_centre].addPoint(points[i]);
                        points[i].setClusterID(id_nearest_centre);
                        done = false;
                    }
                }

                for(int i=0;i<K;i++)
                {
                   
                    for(int j=0;j<total_features;j++)
                    {
                        double sum = 0.0;
                        int total_points_in_cluster = clusters[i].getTotalPointsInCluster();
                        if(total_points_in_cluster>0)
                        {
                            for(int p=0;p<total_points_in_cluster;p++)
                            {
                                sum += clusters[i].getPoint(p).getValue(j);
                            }
                           
                            clusters[i].setCentreValue(j,sum/total_points_in_cluster);
                            
                        }  
                    }
                }

                cout<<"\nIteration: "<<iteration;
                for(int i=0;i<K;i++)
                {
                    cout<<"\nCluster: "<<clusters[i].getClusterID()+1<<endl;
                    for(int j=0;j<clusters[i].getTotalPointsInCluster();j++)
                    {
                        cout<<"Point: "<<clusters[i].getPoint(j).getID()+1<<":  ";
                         for(int f=0 ; f<total_features; f++)
                        {
                            cout<<clusters[i].getPoint(j).getValue(f)<<"\t";
                        }
                        cout<<clusters[i].getPoint(j).getName()<<endl;

                    }
                    for(int l=0;l<total_features;l++)
                    {
                        cout<<"Cluster values: "<<clusters[i].getCentreValue(l)<<"  ";
                    }
              }
        
                if(done == true || iteration>=max_iterations)
                {
                    cout<<"Break at iteration no. : "<<iteration;
                    break;
                }
            
                iteration++;
                                             
                
        }

       




                
    }              
                 


};        
int main()
{
    
    int total_points,total_features,K,max_iterations,hasname;
    cin >> total_points >> total_features >> K >> max_iterations >> hasname;

    vector <Point> points;
    string point_name;
    for(int i=0;i<total_points;i++)
    {
        vector <double> features;
        for(int j=0;j<total_features;j++)
        {
            double value;
            cin >> value;
            features.push_back(value);
        }
        if(hasname)
        {
            cin>>point_name;
            Point p(i,features,point_name);
            points.push_back(p);
        }
        else
        {
            Point p(i,features);
            points.push_back(p);
        }

    }

    Kmeans kmeans(total_points,total_features,K,max_iterations);
    kmeans.run(points);
    return 0;
}
