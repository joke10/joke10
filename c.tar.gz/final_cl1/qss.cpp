#include<iostream>
#include<omp.h>
#include<stdlib.h>
using namespace std;
#define MAX 100

void swap(int* a, int* b)
{
    int t = *a;
    *a = *b;
    *b = t;
} 

int partition(int arr[] , int low , int high)
{
	int pivot = arr[high];
	int i = (low-1);
	for(int j = low ; j<= high-1 ;j++)
	{
		if(arr[j]<=pivot)
		{
			i++;
			swap(&arr[i], &arr[j]);
		}

	}
	swap(&arr[i + 1], &arr[high]);
	return (i+1); 
}

int quicksort(int arr[], int low, int high)
{
	if(low<high){	
	int p = partition(arr,low,high);
	
	quicksort(arr,low,p-1);
	quicksort(arr,p+1,high);
	}
	
	
}

int conc_quicksort(int arr[], int low, int high)
{
	if(high>low){
	int p = partition(arr,low,high);
	
	#pragma omp parallel sections
	{
	
		#pragma omp section
		{
			conc_quicksort(arr,low,p-1);
		}
		#pragma omp section
		{
			conc_quicksort(arr,p+1,high);
		}
	}
}
}

int main(int argc,char *argv[])
{
	int arr[MAX];
	int arr1[MAX];
	int n =100;
	for(int i=0;i<n;i++)
	{
		arr[i]=rand()%100;
	}

	for(int i=0;i<n;i++)
	{
		arr1[i]=arr[i];
	}

	for(int i=0;i<100;i++)
	{
		cout<<arr[i]<<"\t";
	}
	//int arr[] = {10, 7, 8, 9, 1, 5};
	//int n = sizeof(arr)/sizeof(arr[0]);
	//cout<<"\nsize:"<<n;
	cout<<endl;
	double start = omp_get_wtime();
	conc_quicksort(arr1, 0, n-1);
	double stop = omp_get_wtime();
	double elapsed_time = stop - start;
	cout<<"\nTime  taken for concurrent execution: "<<elapsed_time;
	cout<<endl;
	for(int i=0;i<n;i++)
	{
		cout<<arr1[i]<<"\t";
	}
	
	start = omp_get_wtime();
	quicksort(arr, 0, n-1);
	stop = omp_get_wtime();
	elapsed_time = stop - start;
	cout<<"\nTime  taken for sequential execution: "<<elapsed_time;
	cout<<endl;
	for(int i=0;i<n;i++)
	{
		cout<<arr[i]<<"\t";
	}
	cout<<endl;
}


