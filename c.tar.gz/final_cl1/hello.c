#include <stdio.h>
int main()
{
   1.435E04
   int num;
   // printf() displays the string inside quotation
   printf("Hello, World!");
   return 0;
   if(i==1.2);
}
