import json

def print_board(board):
	for i in board:
		print(i)

def isUnderAttack(board,row,column):
	for i in range(row):
		if board[i][column] == 1:
			return True

	i = row -1
	j = column -1
	
	while(i>=0 and j>=0):
		if board[i][j] == 1:
			return True
		i-=1
		j-=1

	i = row-1
	j = column+1
	
	while(i>=0 and j<=7):
		if board[i][j]==1:
			return True
		i-=1
		j+=1

	return False

def solve(board,row):
	column = 0
	while(column<8):
		if( not isUnderAttack(board,row,column)):
			board[row][column]=1
			if(row == 7):
				return True
			else:
				if(solve(board,row+1)):
					return True
				else:
					board[row][column]=0
		column+=1
	if column == 8:
		return False

f = open("eightqueen.json","r")
data = json.load(f)
board = [[0 for x in range(8)]for x in range(8)]
if data["START"]<0 or data["START"]>7:
	print "Gandka Input"
else:
	board[0][data["START"]] = 1
	print "Initial Board: "
	print_board(board)

if(solve(board,1)):
	print "Soluchan:"
	print_board(board)
else:
	print "Gandla"
