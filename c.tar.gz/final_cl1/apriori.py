import sys 
from collections import defaultdict 

def readFile(fn):			#Function readFile 
	f = open(fn,"r") 
	for line in f: 
		line = line.strip().rstrip(",")
		print(line) 
		record = frozenset(line.split(','))  #frozenset removes duplicate items in a 							  #transaction 
		print(record)
		yield record		
		#return record 

def returnItemSetTL(data_iter):		#Function to create first ItemSet 
	_itemSet = set() 
	TransactionList = [] 
	for record in data_iter: 
		trans = frozenset(record) 
		TransactionList.append(trans) 
		for item in trans: 
			_itemSet.add(frozenset([item]))
	print "\n"
	print "Item Set: ",_itemSet
	print "Transaction List: ",TransactionList
	print "\n"
	return _itemSet,TransactionList 

def returnItemWithMinSupport(itemSet,TransactionList,freqSet):	#Function to 									#find frequent patterns 
	localSet = defaultdict(int) 
	_itemSet = set() 
	for item in itemSet: 
		print(item)
		for trans in TransactionList: 
			if item.issubset(trans): 
				localSet[item]+=1 
				freqSet[item]+=1 
	for item,count in localSet.items(): 
		support= count  
		if support>=minSupport: 
			_itemSet.add(item)
		print "\n"
		print "C1: \t Min Support", _itemSet,support 
		print "\n"
	return _itemSet 

def joinSet(itemSet,length):
	print "Join:", set([i.union(j) for i in itemSet for j in itemSet if len(i.union(j))==length]) 		
	return set([i.union(j) for i in itemSet for j in itemSet if len(i.union(j))==length]) 

def getSupport(freqSet,item):	#Function to get Support 
	return freqSet[item] 
	

def runApriori(data_iter,ms):		#Function Apriori 
	itemSet,TransactionList = returnItemSetTL(data_iter) 

	freqSet = defaultdict(int) 
	largeSet = {} 
	oneCSet = returnItemWithMinSupport(itemSet,TransactionList,freqSet) 
	k=2 
	currentLSet = oneCSet 
	print "\nFrequent 1 Item Set: " 
	print currentLSet 
	while(currentLSet!=set([])): 
		largeSet[k-1]=currentLSet
		print "largeSet[%d]: %s"%(k-1,str(largeSet[k-1]))
		currentLSet = joinSet(currentLSet,k) 
		 
		print "" 
		print "Frequent", k, "Item Set:" 
		 
		if currentLSet=={}:
			return
		print currentLSet 
		currentCSet = returnItemWithMinSupport(currentLSet,TransactionList,freqSet) 
		currentLSet = currentCSet 
		k+=1 
		

		 
	items = [] 
	for key,value in largeSet.items(): 
		items.extend([(tuple(item),getSupport(freqSet,item)) for item in value]) 
		 
	print "\nAll Frequent Item Set:" 
	print items 
	max_value = 0
	print(sorted(items,key=lambda(item,support):support)) 
	for item,support in sorted(items,key=lambda(item,support):support): 
		if max_value<len(item): 
			max_value=len(item) 
	for item,support in sorted(items,key=lambda(item,support):support): 
		if max_value==len(item): 
			print "\nLongest Frequent Item Set:\n", item, "\n" 

#main 
inFile = readFile(sys.argv[1]) 

minSupport = int(sys.argv[2]) 
runApriori(inFile,minSupport)

