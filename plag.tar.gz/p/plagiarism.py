from difflib import SequenceMatcher
from flask import Flask, render_template,request
import re

app = Flask(__name__)

@app.route('/')
def start():
	return render_template('start.html')

@app.route('/check',methods=['post'])	
def check():
	cnt=[]
	word_cnt=0
	global s
	if request.method=='POST':
		test_data=request.form['text']
		test_data=re.split(' , |, | . | |\n',test_data)
		word_cnt=len(test_data)
	
	with open("file_1.txt") as file:
		data = file.read()
	data=re.split(' , |, | . | |\n',data)
	
	cnt=set(data)&set(test_data)
	return render_template('result.html', text=(float(len(cnt))/word_cnt)*100)

if __name__ == '__main__':
	app.run(debug=True)
