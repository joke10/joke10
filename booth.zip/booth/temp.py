from flask import Flask,request,render_template
from bitstring import BitArray

app=Flask(__name__)

multiplier=999
multiplicand=999

flag1 = False
flag2 = False

def booth(m, r, x, y):
	# Initialize
	totalLength = x + y + 1
	mA = BitArray(int = m, length = totalLength)
	rA = BitArray(int = r, length = totalLength)
	A = mA << (y+1)
	S = BitArray(int = -m, length = totalLength)  << (y+1)
	P = BitArray(int = r, length = y)
	P.prepend(BitArray(int = 0, length = x))
	P = P << 1
	# print "Initial values"
	# print "A", A.bin
	# print "S", S.bin
	# print "P", P.bin
	# print "Starting calculation"
	for i in range(1,y+1):
		if P[-2:] == '0b01':
			P = BitArray(int = P.int + A.int, length = totalLength)
			# print "P +  A:", P.bin
		elif P[-2:] == '0b10':
			P = BitArray(int = P.int +S.int, length = totalLength)
			# print "P +  S:", P.bin
		P = arith_shift_right(P, 1)
		# print "P >> 1:", P.bin
	P = arith_shift_right(P, 1)

	return P.int

def arith_shift_right(x, amt):
	l = x.len
	x = BitArray(int = (x.int >> amt), length = l)
	return x

@app.route('/')
def index():
	result = 0
	global multiplier
	global multiplicand
	global flag1
	global flag2
	if multiplier == 999 and multiplicand == 999:
		pass
	else:
		print "Some makeshift thingy",multiplier
		m=int(multiplier)
		r=int(multiplicand)
		result = booth(m,r,8,8)	
		# print result
		if result and flag1 and flag2:
			return "The result is: %s" %str(result)
	return render_template('index.html')


@app.route('/Multiplier',methods=['get','POST'])
def Multiplier():
	global multiplier
	global flag2
	if request.method=='POST':
		multiplier = request.form['Multiplier']
		flag2 = True
	# print "The multiplier is: ",multiplier
	return render_template('client1.html')



@app.route('/Multiplicand',methods=['get','POST'])
def Multiplicand():
	global multiplicand
	global flag1
	if request.method=='POST':
		multiplicand = request.form['Multiplicand']
		flag1 = True
	# print "The multiplicand is: ",multiplicand
	return render_template("client2.html")


if __name__ == "__main__":
	app.run(debug=True,host='0.0.0.0')