from flask import Flask, render_template, redirect, url_for, request
from flask_wtf import Form
from wtforms import TextField, RadioField
from math import sin,cos,tan
import xml.etree.ElementTree as ET

app = Flask(__name__)
app.secret_key = 'arun_pottekat'
answer = []
expression = []
number_operator_check = True

class CalculatorForm(Form):
	"""docstring for CalculatorForm"""
	screen = TextField()

@app.route("/", methods=['GET', 'POST'])
def index():
	global expression
	global answer
	form = CalculatorForm()

	if request.method == 'POST':
		if request.form["submit"] == "=":
			expression = "".join(expression)
			form.screen.data = str(eval(expression))
			answer.append(str(eval(expression)))
			expression = [answer[0]]
		elif request.form["submit"] == "Ans":
			expression.append(answer.pop())
			form.screen.data = ("".join(expression))
		else:
			expression.append(request.form["submit"])
			form.screen.data = ("".join(expression))
	
	return render_template("index.html", form=form)

if __name__ == '__main__':
	app.run(debug=True)