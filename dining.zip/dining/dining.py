import threading
import time
import random

from pymongo import MongoClient

# List to store threads
threads = []

# Total no of apples
tot_apples = 10

class dining (threading.Thread):
    def __init__(self, threadID, name, leftKnife, rightKnife):
        # leftKnife, rightKnife are two locks required to access resources

        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.leftKnife = leftKnife
        self.rightKnife = rightKnife


    def run(self):
        global tot_apples

        while 1:
            # thinking
            think = random.randint(1, 10)
            print "\n" + self.name + " is thinking for " + str(think) + "sec."
            time.sleep(think)

            knife1 = self.leftKnife
            knife2 = self.rightKnife

            # Trying to get both the locks or waiting for locks
            knife1.acquire()
            knife2.acquire()

            apples = 1

            if tot_apples>0:                
                task(self.name, apples)
                knife1.release()
                knife2.release()
            else:
                knife1.release()
                knife2.release()
                exit()


def task(threadName, counter):
    global tot_apples

    # Eating
    tot_apples -= counter
    print "\n" + threadName + " is eating " + str(counter) + " apple"
    time.sleep(counter)
    print "\n" + threadName + " is done with eating " + str(counter) + " apple"
    print "Remaining apples are: " + str(tot_apples) + "\n\n"


def calc_tot_apples():
    global tot_apples

    # Calculating total number of apples 

    client = MongoClient()
    db = client.dining
    cursor = db.resources.find()

    for doc in cursor:
        text = str(doc) 
        text = text.strip("}").split(",")

        apple = text[2].split(":")
        apple = int(float(apple[1]))

        tot_apples += apple

    print "Total Apples are: " + str(tot_apples)


# Starting point
name = ["aristotle", "archimedes", "plato", "galileo", "socrates"]
knife = [threading.Lock() for i in range(0,5)]

# Calculating total apples
calc_tot_apples()

# Create new threads
for i in range(0,5):
    #time.sleep(1)
    thread = dining(i, name[i], knife[i%5], knife[(i+1)%5])
    thread.start()
    threads.append(thread)

# Joining threads
for t in threads:
    t.join()

# Exiting from program
print "\n\n0 Apple remaining\nExiting ..."

